//
//  Search.swift
//  vivecatv
//
//  Created by Solar Jang on 9/19/15.
//  Copyright © 2015 mmibroadcasting. All rights reserved.
//

import Foundation

class Search {
    
    var _FilterExpression:String?
    var _type:String?
    var _year:String?
}
