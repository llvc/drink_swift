//
//  adVertisement.swift
//  vivecatv
//
//  Created by Solar Jang on 9/19/15.
//  Copyright © 2015 mmibroadcasting. All rights reserved.
//

import Foundation

class adVertisement: NSObject {
    
    
    var bgimgurl:NSURL?
    var title:String?
    var iN:String?
    var logourl:NSURL?
    var position:String?
    var aux:String?
    var adurl:NSURL?
    
}