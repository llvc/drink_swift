//
//  MusicList.swift
//  vivecatv
//
//  Created by Solar Jang on 9/19/15.
//  Copyright © 2015 mmibroadcasting. All rights reserved.
//

import Foundation

class MusicList: NSObject {
    
    var info:String?
    var musicurl:NSURL?
    var title:String?
    var year:String?
    var iN:String?
    var position:NSInteger?
    var infoUrl:NSURL?
    var aux:String?
}